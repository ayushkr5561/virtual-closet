import React, { createContext, useContext, useState, useEffect } from 'react';
import { getWeatherByCoords, getWeatherByCity, getUserLocation, WeatherData, getWeatherCondition, getSuggestedWeatherTag } from '../services/weather';
import { useUser } from './UserContext';

interface WeatherContextType {
  weatherData: WeatherData | null;
  weatherCondition: string;
  suggestedWeatherTag: 'summer' | 'winter' | 'inbetween';
  isLoading: boolean;
  error: string | null;
  updateLocation: (city: string) => Promise<void>;
  refreshWeather: () => Promise<void>;
}

const WeatherContext = createContext<WeatherContextType | undefined>(undefined);

export const WeatherProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useUser();
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (currentUser) {
      refreshWeather();
    }
  }, [currentUser]);

  const refreshWeather = async () => {
    try {
      setIsLoading(true);
      setError(null);

      // Check if we have a saved location preference
      const savedLocation = currentUser?.preferences?.location;

      if (savedLocation) {
        const data = await getWeatherByCity(savedLocation);
        setWeatherData(data);
      } else {
        // Try to get user's current location
        const location = await getUserLocation();
        
        if (location) {
          const data = await getWeatherByCoords(location.lat, location.lon);
          setWeatherData(data);
        } else {
          // Use default location if geolocation is not available or denied
          const data = await getWeatherByCity('New York');
          setWeatherData(data);
        }
      }
    } catch (err) {
      console.error('Error fetching weather:', err);
      setError('Failed to fetch weather data. Please try again later.');
    } finally {
      setIsLoading(false);
    }
  };

  const updateLocation = async (city: string) => {
    try {
      setIsLoading(true);
      setError(null);
      const data = await getWeatherByCity(city);
      setWeatherData(data);
    } catch (err) {
      console.error('Error updating location:', err);
      setError('Failed to update location. Please check the city name and try again.');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  // Derived state
  const weatherCondition = weatherData 
    ? getWeatherCondition(weatherData.weather[0].id)
    : 'unknown';

  const suggestedWeatherTag = weatherData 
    ? getSuggestedWeatherTag(weatherData.main.temp)
    : 'inbetween';

  return (
    <WeatherContext.Provider
      value={{
        weatherData,
        weatherCondition,
        suggestedWeatherTag,
        isLoading,
        error,
        updateLocation,
        refreshWeather
      }}
    >
      {children}
    </WeatherContext.Provider>
  );
};

export const useWeather = (): WeatherContextType => {
  const context = useContext(WeatherContext);
  if (context === undefined) {
    throw new Error('useWeather must be used within a WeatherProvider');
  }
  return context;
};